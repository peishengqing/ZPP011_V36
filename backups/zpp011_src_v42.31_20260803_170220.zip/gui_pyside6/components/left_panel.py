# -*- coding: utf-8 -*-
"""左侧面板组件 — 卡片式 360px 设计
包含：文件选择 + 替代料配对 + 数据预览
筛选条件由右侧 FilterPanel 独立管理，负责工厂/车间/物料类型/日期等详细筛选
"""
from PySide6.QtWidgets import (
    QWidget, QGroupBox, QVBoxLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QTableWidget,
    QHeaderView,
)
from PySide6.QtCore import Qt, QObject, QEvent


class LeftPanelComponent:
    """左侧面板组件：创建并返回 self.left_panel"""

    def __init__(self, main_window):
        self.mw = main_window
        self.left_panel = self._create_panel()

    def _create_panel(self):
        panel = QWidget()
        panel.setFixedWidth(360)
        panel.setObjectName("leftPanel")
        layout = QVBoxLayout(panel)
        layout.setSpacing(10)
        layout.setContentsMargins(8, 8, 8, 8)

        # 1. 文件选择组
        self.file_group = self._create_card("📁 文件选择", True)
        self._build_file_selection(self.file_group.body_layout)
        layout.addWidget(self.file_group.container)

        # 3. 替代料管理组
        self.alt_group = self._create_card("🔧 替代料配对", True)
        self._build_alternative_materials(self.alt_group.body_layout)
        layout.addWidget(self.alt_group.container)

        # 4. 数据预览组（文字统计：显示行数/列数），默认展开
        self.preview_group = self._create_card("📊 数据预览", True)
        self.mw.preview_label = QLabel("")
        self.mw.preview_label.setObjectName("previewLabel")
        self.mw.preview_label.setStyleSheet("font-size: 11px; padding: 8px; line-height: 1.6;")
        self.mw.preview_label.setWordWrap(True)
        self.preview_group.body_layout.addWidget(self.mw.preview_label)
        layout.addWidget(self.preview_group.container)

        layout.addStretch()
        return panel

    def _create_card(self, title: str, expanded: bool):
        """创建卡片式分组"""
        container = QWidget()
        container.setObjectName("cardContainer")
        layout = QVBoxLayout(container)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # 顶部蓝色条纹
        stripe = QWidget()
        stripe.setObjectName("cardStripe")
        stripe.setFixedHeight(3)
        layout.addWidget(stripe)

        # 头部（可点击）
        header = QWidget()
        header.setObjectName("cardHeader")
        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(12, 10, 12, 10)

        title_label = QLabel(title)
        title_label.setObjectName("cardTitle")
        header_layout.addWidget(title_label)
        header_layout.addStretch()

        arrow_btn = QPushButton("▼")
        arrow_btn.setObjectName("collapseArrow")
        arrow_btn.setFixedSize(20, 20)
        arrow_btn.setCursor(Qt.PointingHandCursor)
        header_layout.addWidget(arrow_btn)

        # 内容区域
        body = QWidget()
        body.setObjectName("cardBody")
        body_layout = QVBoxLayout(body)
        body_layout.setContentsMargins(12, 12, 12, 12)
        body_layout.setSpacing(10)

        if not expanded:
            body.setVisible(False)
            arrow_btn.setText("▶")

        # 连接折叠逻辑：箭头按钮点击 + header 区域点击
        def toggle_state():
            is_visible = body.isVisible()
            body.setVisible(not is_visible)
            arrow_btn.setText("▶" if is_visible else "▼")

        arrow_btn.clicked.connect(toggle_state)

        # header 整个区域可点击（用 eventFilter 拦截 mousePress）
        class HeaderEventFilter(QObject):
            def __init__(self_inner, callback):
                super().__init__()
                self_inner._cb = callback

            def eventFilter(self_inner, obj, e):  # noqa: N802 — Qt override
                if e.type() == QEvent.Type.MouseButtonPress:
                    if e.button() == Qt.MouseButton.LeftButton:
                        self_inner._cb()
                return super().eventFilter(obj, e)

        header_filter = HeaderEventFilter(toggle_state)
        header.installEventFilter(header_filter)

        layout.addWidget(header)
        layout.addWidget(body)

        class CardGroup:
            pass
        group = CardGroup()
        group.container = container
        group.body_layout = body_layout
        group.body = body
        group.arrow_btn = arrow_btn
        group.expand = lambda: (body.setVisible(True), arrow_btn.setText("▼"))
        return group

    def _build_file_selection(self, layout: QVBoxLayout):
        """构建文件选择表单"""
        # 输入文件
        input_row = QHBoxLayout()
        input_row.setSpacing(6)

        input_field = QLineEdit(self.mw)
        input_field.setPlaceholderText("📁 点击'浏览'选文件")
        input_field.setMinimumWidth(150)
        input_field.setObjectName("inputFileEdit")
        input_field.setReadOnly(True)
        self.mw.input_file_edit = input_field

        browse_btn = QPushButton("浏览")
        browse_btn.setObjectName("browseBtn")
        browse_btn.clicked.connect(self.mw._select_input_file)

        input_row.addWidget(input_field, 1)
        input_row.addWidget(browse_btn)

        input_label = QLabel("输入")
        input_label.setObjectName("filterLabel")
        input_label.setStyleSheet("color: #ffffff; font-size: 11px; margin-bottom: 4px;")
        layout.addWidget(input_label)
        layout.addLayout(input_row)

        # 输出目录
        output_row = QHBoxLayout()
        output_row.setSpacing(6)

        output_field = QLineEdit(self.mw)
        output_field.setPlaceholderText("请选择输出目录...")
        output_field.setObjectName("outputDirEdit")
        output_field.setReadOnly(True)
        self.mw.output_dir_edit = output_field

        output_browse_btn = QPushButton("浏览")
        output_browse_btn.setObjectName("browseBtn")
        output_browse_btn.clicked.connect(self.mw._select_output_dir)

        output_row.addWidget(output_field)
        output_row.addWidget(output_browse_btn)

        output_label = QLabel("输出")
        output_label.setObjectName("filterLabel")
        output_label.setStyleSheet("color: #ffffff; font-size: 11px; margin-bottom: 4px;")
        layout.addWidget(output_label)
        layout.addLayout(output_row)

    def _build_alternative_materials(self, layout: QVBoxLayout):
        """构建替代料管理表单"""
        # 计数标签
        self.mw.alt_count_label = QLabel("共 0 对")
        self.mw.alt_count_label.setObjectName("altCountLabel")
        self.mw.alt_count_label.setStyleSheet("color: #ffffff; font-size: 11px;")
        layout.addWidget(self.mw.alt_count_label)

        # 替代料表格
        self.mw.alt_table = QTableWidget()
        self.mw.alt_table.setColumnCount(3)
        self.mw.alt_table.setHorizontalHeaderLabels(["物料A", "↔", "物料B"])
        self.mw.alt_table.setObjectName("altTable")
        header = self.mw.alt_table.horizontalHeader()
        header.setStretchLastSection(False)
        header.setSectionResizeMode(0, QHeaderView.Stretch)
        header.setSectionResizeMode(1, QHeaderView.Fixed)
        header.resizeSection(1, 30)
        header.setSectionResizeMode(2, QHeaderView.Stretch)
        self.mw.alt_table.verticalHeader().setVisible(False)
        self.mw.alt_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.mw.alt_table.setDragEnabled(True)
        self.mw.alt_table.setAcceptDrops(True)
        self.mw.alt_table.setDragDropMode(QTableWidget.InternalMove)
        self.mw.alt_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.mw.alt_table.setAlternatingRowColors(True)
        # 不再内联设置样式，由 QSS 主题统一控制
        self.mw.alt_table.setMinimumHeight(100)
        self.mw.alt_table.setMaximumHeight(150)
        layout.addWidget(self.mw.alt_table)

        # 操作按钮
        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(6)
        for label, handler in [
            ("添加", self.mw._add_alt_pair),
            ("删除", self.mw._delete_alt_pair),
            ("重置", self.mw._reset_alt_pairs),
            ("导入", self.mw._import_alt_pairs),
            ("导出", self.mw._export_alt_pairs),
        ]:
            btn = QPushButton(label)
            btn.setObjectName("altActionBtn")
            # 样式由 QSS 统一控制
            btn.clicked.connect(handler)
            btn_layout.addWidget(btn)
        layout.addLayout(btn_layout)

        btn_layout2 = QHBoxLayout()
        btn_layout2.setSpacing(6)
        for label, handler in [("排序", self.mw._sort_alt_pairs), ("放大", self.mw._zoom_alt_table)]:
            btn = QPushButton(label)
            btn.setObjectName("altActionBtn")
            btn.clicked.connect(handler)
            btn_layout2.addWidget(btn)
        btn_layout2.addStretch()
        layout.addLayout(btn_layout2)

    def _create_input_row(self, parent_layout: QVBoxLayout, label_text: str,
                         placeholder: str, has_browse: bool = False) -> QWidget:
        """创建 label + 输入框行"""
        container = QWidget()
        row_layout = QVBoxLayout(container)
        row_layout.setSpacing(4)
        row_layout.setContentsMargins(0, 0, 0, 0)

        # Label
        label = QLabel(label_text)
        label.setStyleSheet("color: #ffffff; font-size: 11px;")
        row_layout.addWidget(label)

        # Input + Browse
        input_row = QHBoxLayout()
        input_row.setSpacing(6)

        input_field = QLineEdit()
        input_field.setPlaceholderText(placeholder)
        input_field.setObjectName(f"{label_text.lower()}Input")
        input_field.setStyleSheet("""
            QLineEdit {
                background-color: #2C2C2A;
                color: #EAE8E4;
                border: 1px solid #444441;
                border-radius: 4px;
                padding: 4px 8px;
                font-size: 11px;
            }
            QLineEdit:focus {
                border-color: #7F77DD;
            }
        """)
        input_row.addWidget(input_field)

        if has_browse:
            browse_btn = QPushButton("浏览")
            browse_btn.setObjectName("browseBtn")
            browse_btn.setStyleSheet("""
                QPushButton#browseBtn {
                    background-color: #7F77DD;
                    color: white;
                    border: none;
                    border-radius: 4px;
                    padding: 4px 12px;
                    font-size: 11px;
                }
                QPushButton#browseBtn:hover {
                    background-color: #6B63D5;
                }
            """)
            input_row.addWidget(browse_btn)

        row_layout.addLayout(input_row)
        parent_layout.addWidget(container)
        return container
