# -*- coding: utf-8 -*-
"""
ZPP011 生产偏差分析器 — 版本历史集中管理

所有版本号、版本日志均由此文件统一管理，其他模块（GUI、打包脚本等）
通过 import 动态读取，避免硬编码分散。

⚠️ 修改版本号时只需更新本文件，无需改动其他代码。
"""

APP_NAME = "云南达利ZPP011生产偏差分析器"
AUTHOR = "裴盛清"

# 版本列表：最新版本在索引 0
VERSION_HISTORY = [
    {
        "version": "v42.34",
        "date": "2026-08-04",
        "build_datetime": "2026-08-04 09:00:00",
        "fixes": [
            "修复文件夹监控自动加载误读非 SAP 导出文件：新增文件名白名单 _is_monitor_accepted_file",
            "只自动加载 ZPP011_YYYYMMDD[-YYYYMMDD].xlsx（导出范围，含 Excel 副本后缀 (1)）与 ZPP011_SAP_*.xlsx（SAP 自动拉取输出）",
            "排除测试产物（如 _verify_fallback.xlsx）、分析报告、临时锁文件（~$ 开头）；_seed_monitor_baseline 与 _scan_monitor_dir 两处扫描均经该白名单过滤",
        ],
        "title": "修复文件夹监控自动加载误读非 SAP 导出文件",
        "changes": [
            "监控自动加载文件名白名单：只接受 ZPP011_导出范围(SAP 手工导出) 与 ZPP011_SAP_*(SAP 自动拉取)，排除测试/报告/锁文件",
        ],
    },
    {
        "version": "v42.33",
        "date": "2026-08-03",
        "build_datetime": "2026-08-03 18:00:00",
        "fixes": [
            "🔗 修复「未读概览」与「变动提醒」看板数据不一致：未读概览按主表 _post_audit_changed==1 & _read==0 算到 N 条，而看板 get_audit_changes 额外二次重比对 DB 历史基线、在缺基线/重比对相等时把变动行归零，弹出「暂无变动」，导致两边对不上",
            "👁 变动提醒看板改为以主表 _post_audit_changed 列为唯一真相（与未读概览同源），不再二次重比对归零；旧值取自 DB 基线快照、新值取当前主表值，缺基线也照常列出该行。现「概览 N 条 = 看板 N 条」完全一致",
        ],
        "notes": [
            "根因：两个弹窗对「变动提醒未读」用了两套口径——概览宽松（纯 df 列）、看板严苛（额外查 DB 基线并重比对），边界情况下看板归零",
            "已实测排除 data_id 类型(int/str)查不到主键的嫌疑（SQLite 列亲和性会让 int 命中 str 主键），确认是口径不一致而非查询 bug",
        ],
    },
    {
        "version": "v42.32",
        "date": "2026-08-03",
        "build_datetime": "2026-08-03 17:30:00",
        "fixes": [
            "🚑 修复 --windowed（无控制台）exe 启动即崩溃：run_pyside6.py 顶层 faulthandler.enable() 在 sys.stderr 为 None 时抛 RuntimeError: sys.stderr is None。现检测到无控制台即把 sys.stderr/stdout 重定向到 zpp011_stderr.log 再启用 faulthandler，启动不再崩、崩溃堆栈可落盘",
            "🔧 global_exception_hook 错误文案由「已输出到控制台」改为「已输出到日志文件 zpp011_stderr.log」，与实际落盘位置一致",
        ],
        "notes": [
            "此崩溃为历史遗留（v42.30/v42.31 同一份启动文件均会崩），只是此前未真正双击 exe 运行；本次因要查看状态栏已读计数才首次暴露",
            "源码模式（有控制台）下 sys.stderr 不为 None，不触发重定向，行为不变",
        ],
    },
    {
        "version": "v42.31",
        "date": "2026-08-03",
        "build_datetime": "2026-08-03 17:30:00",
        "fixes": [
            "🐞 修复「变动提醒弹窗」（未读概览 / 分析后弹窗）手动标已读不计入状态栏：选中标记、全部标记两处补 self._on_manual_marked(n) 回调，现全部手动入口（右键 / 工具栏 / 预警弹窗 / 偏差预警弹窗 / 变动提醒弹窗）均正确累加手动计数",
            "👁 状态栏「📖 已读：自动 N / 手动 M」标签改醒目样式：加粗蓝字 + 左边框分隔，避免用户注意不到",
        ],
        "notes": [
            "此前 v42.30 仅右键/两弹窗回调了计数器，而用户最常用的「未读概览弹窗标已读」走 data_service.mark_changes_as_read 直连，漏接导致计数恒为 0/0，误以为功能没生效",
            "自动计数仍在 _auto_read_by_rules 成功后累加 _auto_read_count；每批新数据（_on_file_loaded）清零两计数器",
        ],
    },
    {
        "version": "v42.30",
        "date": "2026-08-03",
        "build_datetime": "2026-08-03 09:20:00",
        "fixes": [
            "📊 状态栏常驻「已读计数」标签：📖 已读：自动 N / 手动 M，每批数据清零",
            "手动已读累计覆盖全部入口：右键/工具栏（audit_controller.batch_mark_read 新增 manual_marked 信号）、预警弹窗、偏差预警弹窗，均回调主窗口 _on_manual_marked 累加",
            "自动已读在 _auto_read_by_rules 标记成功后累加 _auto_read_count；新文件加载（_on_file_loaded）清零两个计数器",
        ],
        "notes": [
            "计数口径为「本次数据中自动/手动累计标记已读的条数」，只加不减（标未读为取消动作，不扣减）；toast 错过也能随时回看状态栏",
            "_update_read_counter / _on_manual_marked 对标签已回收（RuntimeError）做容错，关窗时序下不崩",
        ],
    },
    {
        "version": "v42.29",
        "date": "2026-08-02",
        "build_datetime": "2026-08-02 17:50:00",
        "fixes": [
            "🔔 自动已读 toast 显示时间 3s → 6s（_auto_read_by_rules 内 4 处 toast 调用全部加 duration=6000），解决「自动已读闪一下没看清」的盲区",
            "📋 工具栏新增「📋 未读概览」按钮：分析后未读概览弹窗可能被数据/面板挡住，工具栏随时可重开。复用现有单例机制 + 新增 show_unread_summary(force=True) 入口，force=True 时全已读也弹（标题下显示「🎉 全清零啦」副标题，再有新未读自动隐藏）",
        ],
        "notes": [
            "UnreadSummaryPopup 新增 mark_all_clear / clear_all_clear 两个方法（默认 hidden 的 QLabel 副标题），数据变化时主窗口自动切换",
            "工具栏位置在「⚡ 进度」之后，符合「分析 → 概览/进度/未读」流程顺到底",
        ],
    },
    {
        "version": "v42.28",
        "date": "2026-08-02",
        "build_datetime": "2026-08-02 17:15:00",
        "fixes": [
            "🐞 修复打开「自动已读规则」页崩溃（AttributeError: 'AutoReadRuleWidget' object has no attribute '_param_input'）：__init__ 中 edit_name.setText / chk_rule_enabled.setChecked 会同步触发 textChanged/stateChanged → _refresh_summary → _read_param_value 提前访问尚未构建的参数控件。改为在 __init__ 早期先声明 self._param_input = None，并让 _read_param_value 对 None 返回该条件类型默认值",
        ],
        "notes": [
            "v42.27 的 exe 打开自动已读规则页必崩，本版为 v42.27 的必须补丁，建议直接覆盖",
        ],
    },
    {
        "version": "v42.27",
        "date": "2026-08-02",
        "build_datetime": "2026-08-02 17:10:00",
        "features": [
            "✨ 新增「规则中心」对话框（菜单 审核 ▸ ⚙ 规则中心（隔离/已读），工具栏「⚙ 规则」按钮也指向它）：用 Tab 区分两页——① 自动隔离区规则（复用原自动隔离配置）② 自动已读规则，底部「保存全部」一次写盘两者",
            "✨ 自动已读规则可视化配置：支持条件类型 偏差数量等于 / 物料编码前缀 / 物料编码属于集合 / 物料名称包含 / 物料类型等于；多规则 OR 并存、独立启停、增删改排序",
            "✨ 默认内置两条自动已读规则：① 偏差数量=0 ② 物料编码前缀 600（即用户要求的「物料编码前3位 600 开头自动已读」），首次运行自动生成 config/auto_read_rules.json",
        ],
        "fixes": [
            "🔧 解决「自动已读的数据没有告诉我」盲区：旧逻辑只弹一条不列明细的 toast。现按规则分行反馈，例如「✅ 自动已读 120 条｜「偏差数量=0」93｜「物料600开头」27」，状态栏同步保留 6 秒可回看；总开关关闭或单条规则停用均有对应提示",
            "🔧 把原自动隔离规则对话框的内部 UI/逻辑抽成 AutoQuarantineRuleWidget(QWidget)，供规则中心 Tab 嵌入复用，对话框改为薄壳包装，工具栏按钮行为不变",
        ],
        "optimizations": [],
        "notes": [
            "📌 自动已读判定：多条规则 OR；仅对未读行生效（已读行不重复打扰，数据变动会自动翻回未读）；列名用候选名依次探测，缺失则该规则整条不匹配（保守不误伤）",
            "📌 复用 core/auto_read_rules.py 镜像 core/auto_quarantine.py 的结构（load/save + compute_auto_read_mask + build_rule_summary），配置独立存放 config/auto_read_rules.json，实时读取无需重启",
            "📌 验证：py_compile + pyflakes 无 F821/F822；自动已读求值逻辑用真实代码跑通（600 前缀命中、偏差数量=0 命中、已读行跳过、总开关/单条规则停用、配置读写 round-trip 全通过）",
        ],
    },
    {
        "version": "v42.26",
        "date": "2026-08-02",
        "build_datetime": "2026-08-02 16:25:00",
        "features": [],
        "fixes": [
            "🔧 修复潜在必崩点：_on_ai_preprocess_error() 读取 self._ai_preprocess_worker，但该属性全项目从未赋值、__init__ 也未初始化 → 只要 AI 审核后预处理失败走进该降级分支就 AttributeError；已在 __init__ 补 self._ai_preprocess_worker = None（与 v42.22 的 AuditLogger.queue 同类型隐患，pyflakes 查不出实例属性）",
            "🔧 关窗收尾补齐三个后台线程：closeEvent 此前只处理 analysis / ai / alert_monitor / _cache_worker，遗漏 _full_report_worker（完整报告导出）、_ppt_worker（PPT 生成）、_file_worker（大文件后台读取）。导出/生成/读文件途中关窗，主窗口先析构而线程回调后触发，存在崩溃风险；现统一 quit + wait(3000) 收尾并置 None",
        ],
        "optimizations": [
            "⚡ closeEvent 收尾对支持协作式取消的 worker（含 request_cancel 的完整报告 worker）先置取消标志再等待，避免硬等满 3 秒才关窗",
            "🛡️ closeEvent 收尾包 try/except RuntimeError，兼容底层 C++ 对象已被 deleteLater 回收的情形，关窗不再有二次异常风险",
            "🧹 save_snapshot / save_snapshot_batch 不再 except Exception: pass 静默吞错，改为打印 [read_status] 前缀的失败原因（含 data_id / 记录条数 / 异常类型）；仍不向上抛出，不打断主流程。基线写失败会导致「偏差变动」判断失真，此前完全无痕迹可查",
        ],
        "notes": [
            "📌 本版处理 AI 代码质量审查报告「第二批」问题，全部经真实代码逐条核实后才修（报告把 _full_report_worker 与 _ppt_worker 混为一谈，实际两者创建位置与生命周期不同）",
            "📌 验证：py_compile 通过；pyflakes 无 F821/F822；异常留痕与 closeEvent 收尾块均以真实源码 exec 方式做了运行时验证（含「运行中可取消 / 未运行 / C++ 对象已回收」三种 worker 状态），全部通过",
            "📌 改动集中在 gui_pyside6/main_window.py（__init__ + closeEvent）与 core/read_status.py（两处异常处理），不触碰任何分析算法与报表逻辑",
        ],
    },
    {
        "version": "v42.25",
        "date": "2026-08-02",
        "build_datetime": "2026-08-02 14:55:00",
        "features": [],
        "fixes": [],
        "optimizations": [
            "🧹 修复 ws6「异常预警」sheet 头部阈值说明硬编码：note_c 单元格原为写死字符串 '阈值说明：主表明细±10%（业务口径）...'，未跟随 UI 动态阈值；改为 f-string 跟随 dyn_thresh（±{dyn_thresh:.0f}%），UI 设 20% 时显示 ±20%、默认 10% 显示 ±10%",
        ],
        "notes": [
            "📌 这是 v42.22 dyn_thresh 贯穿修复遗留的一处漏网硬编码（用户反馈「分析说明阈值没改」时排查发现，当时 UI 默认值=10% 故未暴露）",
            "📌 仅改 analysis/analyzer.py 第 883 行 1 行字符串，零侵入业务逻辑",
            "📌 验证：py_compile 通过；pyflakes 无 F821/F822；dyn_thresh=20/10 两路径 ws6 头部实测分别显示 ±20%/±10%",
        ],
    },
    {
        "version": "v42.24",
        "date": "2026-08-02",
        "build_datetime": "2026-08-02 14:30:00",
        "features": [],
        "fixes": [
            "🔧 修复 v42.22/42.23 崩溃回归：分析完成回调 _on_analysis_finished_ui 启动后台缓存线程 _FullCacheWorker 时传入 dyn_thresh= 关键字，但该局部类的 __init__ 未声明该形参 → TypeError: unexpected keyword argument 'dyn_thresh'（每次点「分析」后必炸）。给 __init__ 补 dyn_thresh=None 形参并 self.dyn_thresh=dyn_thresh，调用处与兜底分支均能正确接收",
        ],
        "optimizations": [],
        "notes": [
            "📌 根因：v42.22 加 dyn_thresh 贯穿时漏改这个局部类（_FullReportWorker 已加、_FullCacheWorker 漏加）",
            "📌 主表分析本身不受影响，仅分析完成后的缓存线程异步启动时才炸；缓存正常路径复用 LATEST_INTERMEDIATES，Sheet3/4 阈值天然跟随 UI 设置（±20% 实测正确），仅极罕见兜底分支才显式传 dyn_thresh",
            "📌 验证：py_compile 通过；pyflakes 无 F821/F822；do_analysis_v2 三路径（主表 dyn_thresh=20 / 缓存复用中间结果 / 兜底 None）均不崩且阈值正确",
        ],
    },
    {
        "version": "v42.23",
        "date": "2026-08-02",
        "build_datetime": "2026-08-02 14:10:00",
        "features": [],
        "fixes": [],
        "optimizations": [
            "⚡ 取消（cancel）谨慎化：analysis_controller.cancel / audit_controller.cancel_ai_audit 的等待超时由 3000ms 提高到 5000ms，给后台 worker 在自身检查点（AnalysisWorker 的 cancel_check、AIAuditWorker 的 _cancel 轮询、_save_audit_results 前判 _cancel）优雅退出的机会——正常取消不再走到 terminate() 强杀线程，消除正在读 Excel / 写 SQLite 时被硬杀留下文件半截或锁残留的风险；terminate() 仍保留作最后兜底（真卡死才用），兜底后 wait() 确保线程真正结束。仅改 2 行 wait 阈值，零侵入 worker 内部逻辑",
        ],
        "notes": [
            "📌 属代码质量审查报告「第二批」里唯一有真实风险项的稳健化（其余 closeEvent 补 worker、save_snapshot 不吞错暂未做）",
            "📌 范围为用户确认的「只做 terminate 谨慎化」，未扩大改动面",
        ],
    },
    {
        "version": "v42.22",
        "date": "2026-08-02",
        "build_datetime": "2026-08-02 10:30:00",
        "features": [
            "✦ 动态阈值 UI 可调：筛选面板新增「动态阈值」输入框（0~50%，默认10%），贯穿 分析→主表→完整报告 Sheet3/4 数据及说明文字，sheet 描述里的阈值数值不再写死 ±10%",
        ],
        "fixes": [
            "🔧 修复 AuditLogger 后台线程启动即崩：__init__ 从未初始化 self.queue（queue.Queue），_worker 线程 self.queue.get() 直接 AttributeError、log() 同样崩；现补上 self.queue = queue.Queue(maxsize=max_queue_size)（仅被单测实例化，属潜伏缺陷，连自带单测都会挂）",
            "🔧 修复自动已读 mark_read_batch 主线程逐行 SQLite 写入（零偏差行多时界面冻结）：改为两条 executemany 批量化（INSERT OR IGNORE + UPDATE 各一批，单事务一次 commit），与 save_snapshot_batch 同款写法",
            "🔧 Sheet8「偏差原因汇总」备注完整输出——经复现已确认当前源码不截断，本次无代码改动，仅澄清旧版报表的截断现象",
        ],
        "optimizations": [],
        "notes": [
            "📌 合并上一轮未提交的 dyn_thresh 8 文件改动一并发版",
            "📌 代码质量审查报告（AI 生成）经逐条核对，其中 2 处 P1（AIAuditWorker 缩进、_get_conn 重复迁移）为误报，未采纳",
        ],
    },
    {
        "version": "v42.21",
        "date": "2026-08-02",
        "build_datetime": "2026-08-02 09:10:00",
        "features": [
            "✦ 分析完成自动已读：偏差数量=0 的行自动标记为已读（与手动标已读同一套变更检测基线，数量/备注真变了会自动翻回未读）",
            "✦ 自动已读完成后弹轻提示 + 状态栏同步：自动已读 N 条（偏差数量=0）｜食品 X/饮料 Y｜原料 A/包材 B｜其他 C（食品饮料按工厂列分词，原料包材按物料类型列）",
            "✦ 每次分析（含重新分析）都刷新主表（原为仅首次分析刷新，重分析后主表显示陈旧数据的坑一并修复）",
        ],
        "fixes": [
            "🔧 修复设「分析起始日/截止日」筛选后分析崩溃：订单级替代料布尔 mask 用 pd.Series(zip(...)) 默认带 RangeIndex，与日期切片后的非连续 df 索引错位，pandas 3.0.2 把 mask 当标签对齐抛 TypeError: unhashable type: 'Series'（@502 行）；构造时加 index=df.index 对齐",
            "🔧 修复日期区间筛出 0 条达阈值行时 build_sheet5 返回裸 pd.DataFrame([])（零列），后续取 dev_df['流程订单'] 抛 KeyError（@534 行）；空结果现返回带完整列结构的空表，兜底分支先判列",
            "🔧 顺带修复 _FullCacheWorker 后台重跑仍走完整分析，与正式分析结果一致",
        ],
        "optimizations": [],
        "notes": [
            "📌 打包采用 --debug（带控制台），崩溃时可直接查看 traceback",
            "📌 文件本身不缺列，崩溃纯属代码对筛选后非连续索引适配不足 + 空结果缺列；用户原数据 ZPP011_20260701-20260731.xlsx 经裸跑验证正常",
        ],
    },
    {
        "version": "v42.20",
        "date": "2026-08-01",
        "build_datetime": "2026-08-01 18:00:00",
        "features": [
            "✦ 导出「文件被占用」友好提示：新增 save_guard 防护模块，原始 PermissionError 翻译成中文，弹窗三选（我已关闭重试 / 存为副本 / 取消），已接 9 个导出入口（主表当前表/完整报告/隔离区/预警弹窗/偏差率看板/看板HTML/批量导出/PPT）",
            "✦ 主表右键批量导出与工具栏「导出当前表格」均改为导出筛选后显示的数据（遍历 proxy 可见行，所见即所得）",
            "✦ 偏差率预警看板新增「原料/包材」第二组筛选（与全部/未读/已读 叠加，各按钮实时显示点选后可得条数；无物料类型列时整组自动隐藏）",
            "✦ 偏差率预警看板导出改为当前筛选+排序后结果（默认文件名带筛选描述如 偏差率预警_未读_包材.xlsx，空结果拦截不生成空文件）",
            "✦ 未读概览弹窗三修：4 类未读计数与对应看板物理一致（统一 _get_master_df 单一数据源）、标记已读实时刷新、定位修正不再下溢出挡住第二行与关闭按钮、去掉盲关定时器、未清零自动挂起",
        ],
        "fixes": [
            "🔧 修复 df.to_excel 经 xlsxwriter 抛 FileCreateError（包着 PermissionError）导致 except PermissionError 接不住、占用回退失效的真 bug（改为沿异常链判定权限类）",
            "🔧 修复未读概览弹窗未读计数与看板不一致（source_model 副本与 view_model.df 分叉，统一取数口径）",
            "🔧 修复未读弹窗点「查看」后定位异常（show 前 height=0 下溢出屏幕，改 adjustSize 后定位 + showEvent 二次定位）",
        ],
        "optimizations": [],
        "notes": [
            "📌 打包采用 --debug（带控制台），崩溃时可直接查看 traceback",
            "📌 涵盖自 v42.19 起的累积改动：未读弹窗修复、偏差率看板筛选与导出改造、主表/批量筛选后导出、文件占用友好提示",
        ],
    },
    {
        "version": "v42.19",
        "date": "2026-08-01",
        "build_datetime": "2026-08-01 15:10:00",
        "features": [
            "✓ 修复「变动提醒」看板为空 bug：看板数据源由易失的 last_audit_changes 列表改为从主表 _post_audit_changed==1 且未读 的行实时重算（与未读概览弹窗/标记统计共用同一真相），重新分析导致列表被清空后看板不再空白",
            "✓ 主表未读数据存在 ~/.zpp011_audit/audit.db，与清缓存(__pycache__)、打包、预设持久化(已迁用户级)均互不干扰",
        ],
    },
    {
        "version": "v42.18",
        "date": "2026-08-01",
        "build_datetime": "2026-08-01 11:00:00",
        "features": [
            "✦ 新增「未读概览」弹窗：分析/加载完成后自动弹出（非模态、20秒自关、不阻塞主线程），汇总展示 4 类未读数——隔离区 / 变动提醒 / 替代料 / 偏差率预警，每行可点「查看」直达对应看板",
            "✦ 未读口径统一用主表 _read 列（与各看板一致）：隔离区=_quarantined&未读；变动提醒=已改动且未读；替代料=是否替代料且未读；偏差率预警=|偏差率|>=10% 且排除未投料且未读。全部已读则不弹",
        ],
        "fixes": [],
        "optimizations": [],
        "notes": [
            "📌 取代此前被关闭的「变动提醒表格 / 替代料预警」重模态弹窗，新弹窗不阻塞主线程，规避卡顿",
            "📌 触发点：分析完成、工厂切换重载、替代料净偏差重算、隔离/规则配置重预处理后，均会弹出",
        ],
    },
    {
        "version": "v42.17",
        "date": "2026-08-01",
        "build_datetime": "2026-08-01 10:45:00",
        "features": [
            "✦ 物料名称预设存储改为用户级目录（~/.zpp011_audit/material_name_presets.json），exe 内新增/修改预设永久保存，与已读数据同源",
            "✦ 打包配置修复：将整个 config 目录（含根目录 json）纳入 exe，补全此前遗漏的 material_name_presets.json / auto_quarantine_config.json / column_widths.json 等运行时配置",
        ],
        "fixes": [],
        "optimizations": [],
        "notes": [
            "📌 首次运行自动将项目内 config/material_name_presets.json 迁移至用户目录，源码与 exe 共用同一份预设",
            "📌 打包采用 --debug（带控制台），崩溃时可直接查看 traceback",
        ],
    },
    {
        "version": "v42.16",
        "date": "2026-08-01",
        "build_datetime": "2026-08-01 09:00:00",
        "features": [
            "✦ 主表上方常驻标记统计：偏差预警(橙)/替代料(蓝)/未投料(灰) 当前可见条数，随筛选实时动态更新",
        ],
        "fixes": [],
        "optimizations": [],
        "notes": [
            "📌 补发版：v42.15 打包时尚未包含「主表标记统计」功能（提交 7196cc6 于 2026-07-31 18:48，晚于 v42.15 打包），本次将其纳入发布",
            "📌 打包采用 --debug（带控制台），崩溃时可直接查看 traceback",
        ],
    },
    {
        "version": "v42.15",
        "date": "2026-07-31",
        "build_datetime": "2026-07-31 17:00:00",
        "features": [
            "✦ 物料名称预设管理支持拖拽排序+序号显示（1./2./...），新增「全部物料」哨兵项（真正显示全部，不再按字面搜\"全部\"）",
            "✦ 主表格默认显示未读：分析完成 / 重置 / 初始加载均回未读视图",
            "✦ 偏差率预警看板列序调整为定额在前、实际在后（贴合用户习惯）",
            "✦ 隔离原因改为简短规则序号（自动规则[第N条]），释放可见列宽",
            "✦ 隔离区增强：右键切换已读/未读并同步主表、弹窗按隔离原因筛选、原因列位置优化",
            "✦ 变动提醒增强：弹窗进度条防假死、批量标记已读、多行选中(Ctrl/Shift)、大数据量性能优化",
            "✦ 监控文件夹自动加载：发现新 Excel 自动加载（稳定性判定 + 去重 + 重新导出识别）",
            "✦ 自动隔离规则可配置化（JSON + 规则面板）、支持多条规则 OR 并存与规则管理 UI",
            "✦ 替代料看板逻辑增强（组内净偏差差异/偏差率超阈值均进入）且默认未读",
            "✦ 净偏差口径 PPT（build_ppt_net）、智能PPT菜单、Sheet8/9 多耗少耗物料级合计与原因分析列",
            "✦ 物料名称筛选可编辑下拉（用户预设 / 自动灌入常见名）、颜色标记筛选多选 OR 语义",
            "✦ 分析进度面板 v31 风格（12 步骤图标行）+ 右侧全局滚动区 + 替代料配对放大窗口（分组/查找/排序）",
        ],
        "fixes": [
            "🔧 修复预警监控线程裸自旋抢 GIL（拖慢纯 Python 代码约 1000× 的性能元凶）",
            "🔧 根除控制台「快速编辑模式」冻结 + Windows 后台限流导致的卡顿",
            "🔧 修复分析完成后主线程长时间未响应（预处理挪后台线程 + 代理重过滤风暴根治）",
            "🔧 消除分析完成后主表空白（清理上一轮残留代理筛选条件）+ 修复 UnboundLocalError 启动崩溃",
            "🔧 批量 SQLite 写入 + _build_cache 向量化，12K 行下消除\"未响应\"",
            "🔧 修复三类 NameError 低级错（漏导入/漏初始化）+ 物料预设对话框 QListWidgetItem 导入缺失",
            "🔧 修复绿色预警行原生崩溃(segfault)、列头排序崩溃、主表三态排序接入",
            "🔧 修复净偏差率列永远为空、异常预警阈值口径、统计卡片点击直写 proxy 筛选残留",
            "🔧 修复多项 UI 崩溃/截断（筛选面板加宽、下拉长选项截断、弹窗按钮中文等）",
        ],
        "optimizations": [
            "⚡ 诊断打点全面清理 + 统一 debug_util 开关（ZPP011_DEBUG 环境变量，默认静默）",
            "⚡ 主表快速路径：return_dataframe 模式算完偏差明细即返回，跳过导出专用 Sheet 构建",
            "⚡ proxy 预警行判定改缓存 O(1)，消除全表扫描卡顿",
            "⚡ SQLite 连接单例 + map/fill 向量化 + 墙钟时间戳打点",
        ],
        "notes": [
            "📌 本版本补齐 v42.14（2026-07-10）至 v42.15（2026-07-31）累积改动，约 130 次提交合并归纳",
            "📌 工程护栏：引入 pyflakes 提交前静态检查，拦截\"用了没导入的名字\"类低级错",
            "📌 打包采用 --debug（带控制台），崩溃时可直接查看 traceback 定位问题",
        ]
    },
    {
        "version": "v42.14",
        "date": "2026-07-10",
        "build_datetime": "2026-07-10 00:00:00",
        "features": [
            "✦ 新增隔离区功能：疑难数据可一键移入隔离区暂存，主表行浅黄标「隔离区」",
            "✦ 隔离区采用引用模式（仅存 data_id，不存副本），主表数量被改后重新导入，隔离行自动同步，零额外同步代码",
            "✦ 顶部统计卡片新增「⚠️ 隔离区 (X)」卡，点击一键过滤隔离行",
            "✦ 新增隔离区弹窗（工具栏「⚠️ 隔离区」按钮打开），支持批量取消隔离/导出/双击定位",
            "✦ 右键菜单支持「移入隔离区 / 取消隔离」",
        ],
        "fixes": [
            "🔧 修复统计卡片点击失效隐患：原 _on_stats_card_clicked 重复定义导致「审核后变更」卡点击无效，已合并为统一实现并支持隔离区卡点击过滤",
        ],
        "optimizations": [],
        "notes": [
            "📌 隔离区与审核后变更检测共用卡片+过滤模式，数据持久化于 ~/.zpp011_audit/audit.db 的 quarantine_records 表",
        ]
    },
    {
        "version": "v42.13",
        "date": "2026-07-10",
        "build_datetime": "2026-07-10 00:00:00",
        "features": [
            "✦ 复活顶部统计卡片（AI通过率/未读/真异常/替代料），并新增「审核后变更(X)」卡片：点击一键过滤出被私自修改过的数据行",
        ],
        "fixes": [
            "🔧 修复审核后数据被私自修改却「蒙在鼓里」的漏洞：每次加载数据均比对已审核记录的指纹，若实际数量/偏差金额/率被改动，自动打回未读、表格行红标「审核后已变更」、写入 deviation_history 留痕（改前→改后），并弹出变动提醒",
        ],
        "optimizations": [],
        "notes": [
            "📌 数据流：重新导入Excel→重新分析 即触发检测，覆盖主诉实际数量500→550被私自改动场景",
        ]
    },
    {
        "version": "v42.12",
        "date": "2026-07-09",
        "build_datetime": "2026-07-09 15:43:00",
        "features": [
            "✦ 替代料看板改名：原「预警看板」全面更名为「替代料看板」（菜单项/窗口标题/README 统一）",
            "✦ 替代料看板逻辑增强：替代料组内存在偏差差异（净偏差数量≠0）或偏差率超阈值，均进入看板，不再被单行偏差率阈值挡在门外",
        ],
        "fixes": [
            "🔧 修复净偏差率(%)跨订单聚合错误（核心计算模块 net_offset.py，红线区经授权修改）：替代料组净偏差率原按物料组全局聚合，同一替代料对跨多订单时净偏差率被压成≈0%；改为按「订单+组」维度计算，组_20004361@300402336 由 0.01% 修正为 -8.12%",
        ],
        "optimizations": [],
        "notes": [
            "📌 本版本为替代料看板增强与净偏差率计算修复版",
            "📌 net_offset.py 属核心计算冻结区，本次修改经用户明确授权执行",
        ]
    },
    {
        "version": "v42.11",
        "date": "2026-06-28",
        "build_datetime": "2026-06-28 16:15:00",
        "features": [
            "✦ 打包前自动源码备份：build_pyside6.py 增加 281 个源文件自动 zip 备份（保留最近20份）",
            "✦ 暗色主题默认：程序启动默认暗色主题，减少手动切换",
            "✦ 审核统计桌面卡片 P3：4 张实时展示本批次核心指标（审核通过率/需关注/已读未读/备注填写率）的可视化卡片",
            "✦ 历史频率推荐 P2：AI 审核时自动附加同物料+同工厂+同车间的高频备注原因",
            "✦ 成本换算器增强：审核卡片内支持材料偏差列，统计卡片和 PPT 报告增加总偏差金额实物换算",
            "✦ PPT 报告 V3（17页模板）：新增偏差率/预警等级分布/风险等级页面，支持偏差金额A/B双列分析、物料来源追溯、AI归因摘要",
            "✨ 智能小结生成器：基于统计数据生成自然语言报告，一键复制，含免责声明",
            "✨ 批量操作增强：多历史记录导出为多 Sheet Excel",
            "✨ 管理看板增强：图表 PNG 导出（白底/高 DPI）+ 同比/环比（上月/去年同期）",
            "✨ 视图管理：保存/加载/删除/刷新自定义筛选视图",
            "✨ AI 归因分析：物料大类+车间双维度贡献度分析",
        ],
        "fixes": [
            "🔧 回退全屏模式控件可见性判断逻辑（导致按钮/快捷键全部失效），恢复原版",
            "🔧 修复全屏模式状态不一致：基于控件可见性判断代替按钮 checked 状态",
            "🔧 修复全屏合计行高度设置错误（移除 21 行限制，改用固定合计行高度）",
            "🔧 修复全屏水平滚动条不可见 + F11 与按钮状态不一致",
            "🔧 真异常卡片改为可点击，状态栏显示详情",
            "🔧 删除旧版 gui/ Tkinter 目录（35 个文件/13907 行死代码）",
            "🔧 打包前强制校验版本日志已填写，否则拒绝打包",
            "🔧 修复审核来源列被备注来源覆盖",
            "🔧 修复订单类型列显示错误（order_type_val 未被提取和插入）",
            "🔧 修复 PPT 生成 advanced_ppt_generator_v2.py 三处 KeyError",
            "🔧 修复侧边栏筛选失效（替代料列名探测+类型清洗）",
            "🔧 修复预检报告窗口假死（改为非模态）",
            "🔧 修复分析按钮锁泄漏（所有 return 路径释放锁）",
            "🔧 修复 UTF-8 编码问题导致中文乱码",
        ],
        "optimizations": [
            "⚡ 打包流程自动化：版本号验证 + 版本日志校验 + 源码备份 + 打包一步到位",
            "⚡ 暗色主题设为默认启动主题",
            "⚡ 列表头排序修复：补全 _COL_TO_DF 映射及排序方法，替代料筛选列名探测",
        ],
        "notes": [
            "📌 本版本为 v42.10 的综合增强补丁，整合了全屏修复、源码备份、审核卡片、PPT V3 等功能",
            "📌 源码备份路径：C:\\Users\\Administrator\\.zpp011_audit\\source_backups\\",
            "📌 历史频率推荐需 AI 审核完成后可用",
        ]
    },
    {
        "version": "v42.10",
        "date": "2026-06-23",
        "build_datetime": "2026-06-23 17:45:00",
        "features": [
            "✦ 亮色主题支持：完整双主题系统（dark/light QSS），可切换明暗风格",
            "✦ 选中行合计：鼠标选中表格行后，底部状态栏动态显示选中行的数值合计（金额/数量）",
            "✦ 全屏模式保留状态栏：切换到全屏时选中合计依然可见",
        ],
        "fixes": [
            "🔧 删除标题栏物料搜索栏（减少冗余UI）",
            "🔧 删除标题栏自定义窗口控制按钮（复用系统原生按钮，消除点击无反馈问题）",
            "🔧 修复左侧工具栏遮挡右侧筛选面板的颜色问题",
            "🔧 修复文件选择后文件名不显示问题：增加占位符显示和扩展策略",
            "🔧 修复原表行号显示错乱：统一使用 openpyxl 真实行号映射",
            "🔧 异常分析 Sheet6 增加「订单类型」「净偏差数量」「净偏差金额」三列（全链路：生成+导出一致）",
            "🔧 全选选中合计显示为0：修复数值类型转换和求和数据源问题",
        ],
        "optimizations": [
            "⚡ 主题系统从内联 setStyleSheet 迁移至外部 QSS 文件，~70 处硬编码样式统一收口到 dark_theme.qss / light_theme.qss",
            "⚡ 选择变更通过 selectionChanged 信号实时触发底部状态栏更新，无性能损耗",
        ],
        "notes": [
            "📌 本版本为 UI 优化与主题增强版，零核心功能变更",
            "📌 亮色主题切换：菜单栏 → 视图 → 切换主题（亮色/暗色）",
            "📌 选中行合计：按住 Ctrl 可多选行查看合计，按 Ctrl+A 全选也可查看",
        ]
    },
    {
        "version": "v42.8",
        "date": "2026-06-11",
        "build_datetime": "2026-06-11 22:45:00",
        "features": [
            "✦ Agnes AI 批量审核：一次 API 调用处理 15 条，大幅提速",
            "✦ 审核结果 SQLite 持久化：审核结果/AI建议/备注来源跨 session 记忆",
            "✦ 双击主表格弹出明细卡片（三组信息，全部可复制）",
            "✦ 主表格 Ctrl+C 复制选中区域（TSV 格式，可粘贴到 Excel）",
            "✦ 筛选面板新增：审核结果（合格/需关注/需改进/需补备注）、备注来源（AI审核/人工填写）"
        ],
        "fixes": [
            "🔧 修复审核结果列名中英文混乱导致重复列/数据丢失",
            "🔧 修复 _替代料组 与 替代料组 同时存在的空列问题",
            "🔧 修复明细卡片列名模糊匹配（空格/别名）",
            "🔧 修复 AI 审核进度卡在 0% 的问题",
            "🔧 修复批量 API 超时后逐条重试浪费时间（改为直接 Mock 降级）",
            "🔧 修复 config/constants.py 和 __init__.py 的 VERSION 引用残留",
            "🔧 修复 workers.py try/except 缩进丢失",
            "🔧 修复 _build_cache 重复索引导致 Series 判空崩溃"
        ],
        "optimizations": [
            "⚡ AI 审核两阶段：本地分类（瞬间）→ 批量 API（15条/批），1000条从50分钟→3分钟",
            "⚡ HTTP 超时单条 15s→5s、批量 45s→20s，API 不通快速降级",
            "⚡ 列清理流程前置到 preprocess_audit_data 开头，防重复蔓延",
            "⚡ 明细卡片 _mk_label 统一创建可选中文案标签",
            "⚡ filter_panel 审核状态→审核结果，选项匹配 AI 输出值"
        ],
        "notes": [
            "📌 v42.8 基于 v42.7，重点完善 AI 审核流程和列数据完整性",
            "📌 Agnes AI 国内网络可能不稳定，超时 5s 即降级 Mock，不影响基础功能",
            "📌 审核结果已持久化，重新分析后自动恢复历史审核数据"
        ]
    },
    {
        "version": "v42.7",
        "date": "2026-06-11",
        "build_datetime": "2026-06-11 21:00:00",
        "features": [
            "✦ Agnes AI 真模型接入：制造业偏差智能审核，自动生成可执行建议（免费，20 RPM）",
            "✦ AI 审核上下文增强：传递物料编码/描述/大类/车间/工厂/偏差金额等完整信息",
            "✦ 历史源码入口：菜单栏「历史 → 历史源码」打开源码备份目录",
            "✦ 打包前自动备份源码：zip 备份全部源码，保留最近 20 份",
            "✦ 已读/未读 SQLite 持久化（指纹比对 + 跨 session 记忆）",
            "✦ 预警看板右键菜单支持多选批量标记已读/未读",
            "✦ 预警看板标记已读后主表格实时同步刷新"
        ],
        "fixes": [
            "🔧 修复已读状态不持久化：DataService 类未导入/未实例化，预处理管线完全失效",
            "🔧 修复 data_id 含工厂前缀与 DB 不匹配，统一为「订单日期|流程订单|物料编码」",
            "🔧 修复 export_controller.py 多层 try/except 语法错误（重复块 + 缩进）",
            "🔧 修复主表格右键批量标记 data_id KeyError（缺少列时动态生成）",
            "🔧 修复 QMenu/QAction/QMessageBox 等类未导入 main_window.py",
            "🔧 修复 SQLite is_read 列 numpy int64 存为 blob 导致读取失败",
            "🔧 修复预警看板 _sync_main_df 修改后未刷新主表视图"
        ],
        "optimizations": [
            "⚡ 版本号统一到 utils/version_history.py（get_current_version），消除 5 处硬编码",
            "⚡ ConfigManager tkinter API 加守卫：PySide6 环境静默跳过防崩",
            "⚡ 所有控制器 except 块增加 traceback.print_exc()，异常堆栈完整输出",
            "⚡ save_read_status 类型加固 int()/str() 强转，防止 blob 存储",
            "⚡ 删除 config/constants.py 僵尸 VERSION=\"v36\""
        ],
        "notes": [
            "📌 本版本修复了 v42.0→v42.7 迁移期间累积的所有语法和持久化崩漏",
            "📌 源码备份需执行 build_pyside6_exe.py 打包时自动触发",
            "📌 版本号以后只需改 version_history.py 一处，所有界面自动跟随"
        ]
    },
    {
        "version": "v41.3",
        "date": "2026-06-03",
        "build_datetime": "2026-06-03 23:05:00",
        "features": [],
        "fixes": [
            "🐛 修复 audit_batch_events.py 缩进错误导致批量操作无法使用",
            "🐛 修复表格列顺序错乱（补充「备注来源」列）",
            "🐛 修复 export_events.py 缺少 with_feedback 导入",
            "🐛 修复 ppt_generator 依赖 matplotlib 缺失导致程序启动失败",
            "🐛 修复 analyzer.py 文件名日期截断问题（结束日期缺少年份）",
            "🐛 修复 analysis_events.py 列映射时覆盖已有列",
            "🐛 重写 AI 审核规则，增加 5%≤偏差率<10%「需关注」分级，优化关键词与字数优先级",
            "🐛 修复 AI 审核范围过窄（AI 审核过的短备注可重新审核）",
            "🐛 修复排序与筛选冲突（_apply_sort_and_refresh 优先使用 filtered_data）"
        ],
        "optimizations": [
            "⚡ 优化 matplotlib 导入方式，未安装时仅影响 PPT 生成功能"
        ],
        "notes": [
            "📌 本版本为 v41.3 紧急修复版，解决了多个稳定性问题",
            "📌 重写 AI 审核规则后需重新运行 AI 审核以获得更准确结果",
            "📌 建议所有用户升级至此版本"
        ]
    },
    {
        "version": "v41.2",
        "date": "2026-06-03",
        "build_datetime": "2026-06-03 14:50:00",
        "features": [
            "✨ PPT报告V3（17页模板结构）：新增偏差率/预警等级分布/风险等级页面，支持偏差金额A/B双列分析，物料来源追溯，AI归因摘要",
            "✨ 效益报告（8页完整版）：执行摘要、车间排行、物料排行、趋势分析、成本换算、改进建议、附录",
            "✨ 规则配置界面：帮助菜单新增入口，RuleConfigDialog 支持正则匹配、优先级、颜色定制"
        ],
        "fixes": [
            "🐛 GBK编码兜底：MessageBox 全量参数 `_safe_for_gbk` 包装，错误消息去除emoji/非GBK字符",
            "🐛 Worker线程 `sys.stdout.flush` OSError崩溃（加try/except防护）",
            "🐛 PPT生成 `line[0].isdigit()` 空字符串IndexError（4处，改为 `line and line[0].isdigit()`）",
            "🐛 偏差率/偏差金额字符串无法格式化（加 `pd.to_numeric(..., errors='coerce')`）"
        ],
        "optimizations": [
            "⚡ `_safe_for_gbk` 工具函数：strip非GBK字符 + encode('gbk','replace') 双重保险",
            "⚡ 临时文件清理延后到程序退出时执行，减少运行干扰"
        ],
        "notes": [
            "📌 PPT V3 修复 line[0].isdigit() 空字符串风险（line 672, 800, 979, 1022）",
            "📌 规则配置支持正则表达式、优先级排序、颜色标记（红/黄/绿）",
            "📌 本版本基于v41.0合并后的稳定版"
        ]
    },

    
    {
        "version": "v41.0",
        "date": "2026-06-01",
        "build_datetime": "2026-06-01 21:00:00",
        "features": [
            "✨ 可视化规则配置界面（图形化编辑备注校验规则，支持多条件组合、测试、原子保存）",
            "✨ 效益报告（一键生成PPT，包含执行摘要、车间排行、物料排行、趋势分析、成本换算、改进建议）",
            "✨ AI 归因分析增强（增加物料大类贡献度、偏差方向分解、审核进度等维度）",
            "✨ 合计行按单位汇总弹窗（解决不同单位数量无法合并的问题）"
        ],
        "fixes": [
            "🐛 管理看板下钻修复（点击物料大类柱状图自动筛选主表格）",
            "🐛 AI 归因分析无内容修复（兼容缺少物料大类列的情况）",
            "🐛 视图导入导出测试失败修复（完善返回值和方法签名）",
            "🐛 加载审核数据时临时文件提前删除导致报错修复"
        ],
        "optimizations": [
            "⚡ 成本换算器增强（审核卡片内支持材料偏差列，统计卡片和F6报告增加总偏差金额实物换算）",
            "⚡ 审核卡片中文化（字段显示中文，与黄金模板同步）",
            "⚡ 审核表格增加订单类型列，物料大类优先使用原表组件物料类型描述",
            "⚡ 历史菜单恢复（分析完成后显示）"
        ],
        "notes": [
            "📌 本版本基于 v40.2 补丁，新增多项核心功能，建议所有用户升级",
            "📌 可视化规则配置需注意表达式安全性，已采用 AST 解析 + 字段白名单",
            "📌 效益报告依赖 python-pptx 库，打包时已包含",
            "📌 归因分析需历史数据支持，至少两次分析记录才能显示对比"
        ]
    },

    {
        "version": "v40.2",
        "date": "2026-06-01",
        "build_datetime": "2026-06-01 14:00:00",
        "features": [
            "✨ 统计卡片增加总偏差金额汇总，单位一致时显示实物量换算",
            "✨ F6 预检报告增加偏差总金额和实物量估算"
        ],
        "fixes": [
            "🐛 修复历史菜单在进入界面后消失的问题（菜单恢复）"
        ],
        "optimizations": [
            "⚡ 审核卡片字段中文化（工厂、车间、订单日期等），与黄金模板同步",
            "⚡ 成本换算器增强：优先使用材料偏差列计算实物量，支持实际-定额备选计算"
        ],
        "notes": [
            "📌 本版本基于黄金模板 audit_cols_config.py 统一列配置",
            "📌 成本换算器不再依赖预计算单价，直接使用偏差金额/偏差数量（或实际-定额）",
            "📌 历史菜单已恢复，需至少一次分析记录后显示"
        ]
    },
    {
        "version": "v40.1",
        "date": "2026-05-31",
        "build_datetime": "2026-05-31 12:30:00",
        "features": [
            "✨ 管理看板：图表导出为 PNG（白底、高 DPI），支持同比/环比（上月/去年同期）",
            "✨ 智能小结：基于统计生成自然语言报告，一键复制，含免责声明",
            "✨ 批量操作：多历史记录导出为多 Sheet Excel；批量导入备注（预演模式 + 自动备份）",
            "✨ 合计行：表格底部动态显示定额、实际、偏差金额合计（随筛选更新）",
            "✨ 审核卡片内增加成本换算器（偏差金额 → 实物数量，需含单价数据）"
        ],
        "fixes": [
            "🐛 恢复双击审核表格弹窗（修复弹窗无内容问题，任务卡021）"
        ],
        "optimizations": [
            "⚡ 审核表格增加「单位」列（任务卡022）",
            "⚡ 物料大类优先使用原表「组件物料类型描述」列，缺失时回退前缀映射（任务卡023）",
            "⚡ 物料描述截断长度从20增加到30字符（任务卡024）"
        ],
        "notes": [
            "📌 本版本为 v40.1 补丁版，保留分页滚动、标签缓存等全部原有功能",
            "📌 成本换算器需原始数据包含「金额-实际(含税)」和「数量-实际」列",
            "📌 导出 PNG 需安装 Pillow，已加入 requirements.txt",
            "📌 同比/环比查询依赖历史数据库，需至少一次历史记录"
        ]
    },
    {
        "version": "v39.5",
        "date": "2026-05-29",
        "build_datetime": "2026-05-29 18:00:00",
        "features": [
            "Treeview 无限滚动加载：首屏仅 500 行，滚动到底部自动追加（滑动窗口控制内存）",
            "Tag 状态缓存：全量刷新（筛选/排序）时直接从缓存读取行颜色，避免重复计算，性能提升 80% 以上",
            "列宽配置持久化：用户拖拽列宽后自动保存，程序重启后恢复；增加防递归锁和延迟保存机制",
            "SQLite 数据沉淀：每次分析结果自动存入历史库（元数据 + 明细），支持历史查询与同期对比",
            "历史对比界面：可选择任意两次分析，对比总行数、偏差率分布、审核完成率、备注填写率；若筛选条件不同自动警告",
            "四色标记修复：偏差率 >30% 红、>20% 橙、>10% 黄、<=10% 绿，表格背景色正确显示"
        ],
        "fixes": [
            "修复物料大类筛选仅包材有效的问题：统一使用物料编码前缀映射生成 material_category 列，并在筛选前动态补全",
            "修复统计卡片（总记录/偏差>10%/需补备注/已审核）始终显示 0 的问题",
            "修复颜色筛选兼容两种内部键名（_color / priority_color）",
            "修复帮助菜单关于无响应，改为显示完整版本日志窗口",
            "修复替代料配对界面空白（v39.4 回归）",
            "修复四个筛选排序问题（替代料筛选、多条件、互扰、三态）"
        ],
        "optimizations": [
            "分页加载 + tag 缓存：1 万行表格操作响应时间从秒级降至毫秒级",
            "列宽持久化：拖拽列宽后延迟保存，避免频繁 I/O",
            "SQLite 批量插入：1 万行写入 < 1 秒，幂等性检查防止重复入库",
            "测试基线建立：核心模块单元测试覆盖率 > 75%，CI 自动运行"
        ],
        "notes": [
            "基于 v39.4.2 修复版，累计性能优化与数据沉淀核心功能",
            "已知遗留问题：物料大类列名在数据库保存时可能因中文差异缺失数据，建议后续统一",
            "打包命令：python build_exe.py，输出文件名 ZPP011偏差分析器_v39.5_YYYYMMDD_HHMMSS.exe"
        ]
    },

    {
        "version": "v39.4.2",
        "date": "2026-05-28",
        "build_datetime": "2026-05-28 21:00:00",
        "features": [],
        "fixes": [
            "🐛 修复物料大类筛选仅「包材」有效的问题：统一使用物料编码前缀计算 material_category 列，修正 MRO 遮蔽导致下拉选项动态收缩，并补全 _on_load_done 数据路径中 material_category 列的创建逻辑",
            "🐛 修复统计卡片（总记录/偏差>10%/需补备注/已审核）始终显示 0 的问题：扩大 try/except 作用域覆盖整个统计计算块",
            "🐛 修复筛选栏中「审核来源」筛选值不匹配的问题，统一为「AI审核」",
            "🐛 修复订单日期筛选控件宽度过窄导致显示不全的问题：调整 DateEntry 宽度及列宽映射",
            "🐛 修复颜色筛选兼容两种内部键名（_color / priority_color）",
            "🐛 修复帮助菜单「关于」无响应，改为显示完整版本日志窗口",
            "🐛 修复替代料配对界面空白（v39.4 回归）",
            "🐛 修复筛选排序模块拆分后导致的筛选栏消失、启动崩溃等问题",
            "🐛 修复四个筛选排序问题（替代料筛选、多条件、互扰、三态）"
        ],
        "optimizations": [
            "⚡ 筛选排序模块独立抽取为 FilterManager / SortManager（零逻辑改动，依赖注入原则）",
            "⚡ 默认输出目录和输入文件浏览对话框默认路径统一设置为 E:\\zpp011_dev\\ZPP011导出文件原数据",
            "⚡ 订单日期筛选控件宽度适配，避免显示不全",
            "⚡ 删除表格内重复的「筛选」列残留",
            "⚡ 颜色筛选增加 _priority_label 列生成逻辑（偏差率>30%→红, >20%→橙, >10%→黄, 其他→绿）"
        ],
        "notes": [
            "📌 基于 v39.4.1 基建版本（自动备份、审计日志、健康检查）的修复补丁",
            "📌 物料大类筛选现已完全基于物料编码前缀映射，支持原辅料、包材、食品/饮料辅料、食品/饮料成品、促销品等类别",
            "📌 本版本需重新打包，打包命令：python build_exe.py"
        ]
    },
    {
        "version": "v39.4.1",
        "date": "2026-05-28",
        "build_datetime": "2026-05-28 09:10:00",
        "features": [
            "✨ 审核区订单日期筛选改用 tkcalendar 日历控件，提升日期选择体验",
            "✨ 操作审计日志：记录所有审核操作，支持CSV导出，自动清理180天前日志",
            "✨ 健康检查面板：检查依赖、配置、磁盘、数据库、备份恢复，提供 dry-run 模拟分析"
        ],
        "fixes": [
            "🐛 修复颜色筛选兼容两种内部键名（_color 和 priority_color），确保筛选准确"
        ],
        "optimizations": [
            "⚡ 默认输出路径修改为 ~/Documents/ZPP011分析报告",
            "⚡ 输入文件浏览对话框默认打开 E:\\zpp011_dev\\ZPP011导出文件原数据 目录",
            "⚡ 日历控件宽度适配，避免显示不全",
            "⚡ 分析前自动备份，崩溃后可恢复（保留最近10份）"
        ],
        "notes": [
            "📌 基建任务完成：自动备份+审计日志+健康检查",
            "📌 筛选排序模块拆分（任务001）未完成，替代料配对界面空白（BUG-P0）待修复",
            "📌 表格内重复的\"筛选\"列未删除，计划 v39.4.2 处理"
        ]
    },
    {
        "date": "2026-05-26",
        "build_datetime": "2026-05-26 15:30:00",
        "features": [
            "✨ 进度细化：分析时显示5个阶段（读取→解析→计算→匹配→生成），超时熔断5分钟",
            "✨ 防重复点击：分析按钮点击后立即禁用，使用线程锁防止并发",
            "✨ 错误友好化：5个高频错误弹窗，JSON配置，支持打包路径，兜底机制"
        ],
        "fixes": [
            "🐛 修复分析按钮锁泄漏（提前return未释放锁）",
            "🐛 修复t.start()异常后仍启动线程的问题",
            "🐛 修复部分调试print残留（v39.4.1继续清理）"
        ],
        "optimizations": [
            "⚡ 技术债务清理：删除4处@with_feedback装饰器及无用import",
            "⚡ 代码整洁：删除多个临时脚本和debt_list.txt"
        ],
        "notes": [
            "📌 止血版本，核心功能已验证（进度、防重、错误提示）",
            "📌 剩余调试print清理留待v39.4.1"
        ]
    },
    {
        "version": "v39.3",
        "date": "2026-05-25",
        "build_datetime": "2026-05-25 14:30:00",
        "features": [
            "✨ 右键复制物料编码：选中行右键菜单，复制物料编码到剪贴板（反查数据源，不依赖列顺序）",
            "✨ 预检报告弹窗改为非模态：显示系统检查与数据统计，不再阻塞主窗口操作"
        ],
        "fixes": [
            "🐛 修复表格排序崩溃（补全 _COL_TO_DF 映射及排序方法）",
            "🐛 修复侧边栏筛选全部失效（替代料列名探测+布尔/字符串类型清洗）",
            "🐛 修复调试 print 残留及 @with_feedback 装饰器冗余弹窗",
            "🐛 修复右键菜单覆盖原有功能（追加「复制物料编码」而非替换）"
        ],
        "optimizations": [
            "⚡ 预检报告窗口独立关闭，不干扰审核流程",
            "⚡ 代码整洁：移除调试输出与冗余装饰器"
        ],
        "notes": [
            "📌 v39.3 建议所有用户升级，提升筛选与排序稳定性"
        ]
    },
    {
        "version": "v39.1",
        "date": "2026-05-23",
        "build_datetime": "2026-05-23 01:11:56",
        "features": [
            "✨ 修复 load_audit_data 缺失（AuditPresenter 可正常加载审核记录）",
            "✨ 规则文件自动创建（RuleEngine 初始化时生成默认 rules.json）"
        ],
        "fixes": [
            "🐛 修复 AuditPresenter.load_audit_data 方法缺失（AttributeError）",
            "🐛 修复规则文件不存在警告（控制台不再报错）"
        ],
        "optimizations": [
            "⚡ 规则引擎增强：文件缺失时自动创建默认配置，无需手动创建"
        ],
        "notes": [
            "📌 测试版，请裴哥手动测试验证修复效果",
            "📌 若测试通过，可发布为正式版 v39.1"
        ]
    },
    {
        "version": "v39",
        "date": "2026-05-22",
        "build_datetime": "2026-05-22 17:46:32",
        "features": [
            "✨ 拆分 events.py：27,492 行 → 8 个 handler 模块",
            "✨ 硬编码外部化：基于 JSON 版 ConfigManager，阈值/颜色/路径可配置",
            "✨ 配置存储：~/.zpp011_audit/config.json，支持窗口几何记忆"
        ],
        "fixes": [
            "🐛 修复缺失导入（RuleEngine、deepcopy），程序可正常启动",
            "🐛 筛选功能恢复正常"
        ],
        "optimizations": [
            "⚡ 代码守恒：总有效代码 ≤950 行，零逻辑变更",
            "⚡ 配置外部化消除硬编码，提升可维护性"
        ],
        "notes": [
            "📌 重构预览版，核心功能已验证（加载、筛选、AI审核、PPT导出）",
            "📌 遗留问题：AuditPresenter.load_audit_data 缺失（手动加载可绕过）"
        ]
    },
    {
        "version": "v38",
        "date": "2026-05-22",
        "build_datetime": "2026-05-22 11:15:00",
        "features": [
            "PPT v1.3: 分工厂多耗/少耗Top10、环形饼图、柱状图",
            "筛选栏重构：全列动态筛选、历史记忆、重置按钮"
        ],
        "fixes": [
            "B004：双击表格行弹窗无效",
            "B005：自动结案线程安全（Queue通信、超时处理）",
            "PPT页数缺失问题"
        ],
        "optimizations": [
            "参数化配置：阈值、超时、上限可配置",
            "日志脱敏：不记录金额、备注原文"
        ],
        "notes": [
            "冻结期版本，仅修Bug，无新功能"
        ]
    },

    {
        "version": "v37.45",
        "date": "2026-05-22",
        "build_datetime": "2026-05-22 00:18:00",
        "features": [
            "PPT v1.2: DataFrame direct input, no Excel path, global pd import"
        ],
        "fixes": [
            "_pre_aggregate_data missing pd import -> global import pandas as pd",
            "tests: 19/19 passed"
        ],
        "optimizations": [
            "PPT progress 0-100%%, 20 stages, 9889 rows <30s"
        ],
        "notes": [
            "TASK-001: PPT Gen v1.2"
        ]
    },
    {
        "version": "v37.44",
        "date": "2026-05-20",
        "build_datetime": "2026-05-20 23:45:50",
        "features": [
            "【核心】审核记录存储机制升级：业务主键三元组替换原表行号"
        ],
        "fixes": [
            "修复跨文件行号错位问题：行号在文件间不连续导致备注写入错误行"
        ],
        "optimizations": [
            "优化审核回填性能：SQL LEFT JOIN 替代 Python 循环匹配"
        ],
        "notes": [
            "升级用户首次启动弹窗询问是否清空旧数据（点击「是」清空历史，「否」迁移旧记录）"
        ]
    },
    {
        "version": "v37.4.3",
        "date": "2026-05-20 19:19:00",
        "changes": [
            "🔧【修复】全局清除 flush=True（analyzer.py + sheet1/2/3/7/10 共15处）",
            "🔧【修复】删除函数体内重复 import os（Line 127，导致局部变量遮蔽）",
            "🔧【修复】两层数值列保护（pd.to_numeric errors=coerce + fillna 0）",
            "📝【追踪】数量-实际值变化追踪日志（zpp011_trace.log）"
        ]
    },
    {
        "version": "v37.4.0",
        "date": "2026-05-20 12:25:00",
        "changes": [
            "🔧【修复】窗口标题版本号同步（version_history.py新增v37.4.0条目）",
            "🔧【修复】打包文件名格式（增加YYYYMMDD_HHMM时间戳后缀）",
            "🔧【修复】原表行号改用openpyxl真实读取（替代pandas range估算）",
            "✨【优化】进度条流畅（update_idletasks + sleep 0.01 + 节流）"
        ]
    },
    {
        "version": "v37.3.0",
        "date": "2026-05-20 11:00:00",
        "changes": [
            "🔧【修复】PPT生成列名不匹配导致KeyError（自动检测'工厂名称'/'工厂'、'总偏差金额(含税)'/'总偏差金额'）",
            "🔧【修复】进度条不更新/界面假死（events.py强制update_idletasks + analyzer.py让出CPU时间片）",
            "🔧【验证】原表行号_excel_row赋值正确（line 118，过滤前赋值，数据链路完整）"
        ]
    },
    {
        "version": "v37.2.0",
        "date": "2026-05-20 01:30:00",
        "changes": [
            "🔧【修复】deepcopy未导入导致自动结案崩溃",
            "🔧【修复】Font未导入导致保存审核结果崩溃",
            "🔧【修复】_refresh_audit_tree()缺参数导致TypeError",
            "🔧【修复】audit_tree.index()不存在导致隔离区崩溃",
            "🔧【修复】Toplevel缺tk.前缀+center_window未定义",
            "🔧【修复】storage.py数据库连接泄漏（try/finally）",
            "🔧【统一】6项P0崩溃Bug全部修复（元宝+豆包审核）"
        ]
    },
    {
        "version": "v36.40.3",
        "date": "2026-05-18 07:20:00",
        "changes": [
            "🔧【修复】删除analyzer.py重复build_sheet2调用（P0，Lengths must match崩溃）",
            "🔧【修复】_s01_populate_table改用itertuples提升性能",
            "🔧【修复】恢复events.py缺失的run_app()函数",
            "🔧【修复】统一临时目录路径为~/.zpp011_audit/temp",
            "🔧【修复】exporter.py改用shutil.move替代os.replace",
            "✨【新增】build_exe.py打包文件名含时间戳",
            "✨【新增】打包前自动备份源码和exe",
            "✨【继承】S01异步化+高亮（v36.39.0全部功能）"
        ]
    },
    {
        "version": "v36.39.0",
        "date": "2026-05-18 05:30:00",
        "changes": [
            "✨【新增】S01库存检查异步化：独立线程执行，支持进度回调/取消/异常隔离",
            "✨【新增】Tab数据深拷贝缓存：_tab_data_cache，切换Tab保存/恢复数据",
            "✨【新增】临时文件管理：temp/目录，启动时自动清理.s01.tmp/.s01.temp",
            "✨【新增】get_s01_rules()方法：返回s01./inventory.开头的规则配置",
            "✨【新增】_ensure_temp_dir()方法：确保temp/目录存在",
            "✨【新增】_s01_on_tab_changed()方法：Tab切换时数据保存/恢复",
            "✨【新增】S01库存异常高亮：支持配置化规则/颜色（_evaluate_condition/_s01_setup_treeview_tags/_s01_populate_table）",
            "🔧【改进】itertuples替代iterrows：提升遍历性能，每50行检查取消标志",
            "🔧【改进】线程安全UI更新：所有回调通过root.after(0, ...)投送到主线程"
        ]
    },
    {
        "version": "v36.38.0",
        "date": "2026-05-17 13:30:00",
        "changes": [
            "✨【新增】自动结案异步化：_auto_close改为异步启动器+进度条",
            "✨【新增】AutoCloser类（core/AutoCloser.py）：异步结案，支持进度回调/取消/异常隔离",
            "✨【新增】_on_auto_close_progress回调：进度百分比+ETA显示",
            "✨【新增】_on_auto_close_done回调：显示成功/失败数量，刷新界面",
            "✨【新增】_on_auto_close_error回调：取消时数据回滚，显示错误",
            "✨【新增】_cancel_auto_close方法：取消标志设置",
            "✨【新增】取消自动结案按钮（ui_builder.py）：红底白字，默认disabled",
            "🔧【修复】规则引擎接口兼容：check_auto_close_condition/should_close/evaluate兜底",
            "🔧【改进】规则漂移保护：深拷贝rule_engine防止结案过程中规则变化"
        ]
    },
    {
        "version": "v36.37.0",
        "date": "2026-05-17 12:30:00",
        "changes": [
            "✨【新增】批量导出异步化：_export_audit_excel改为异步启动器+进度回调",
            "✨【新增】ExcelExporter类（core/exporter.py）：异步导出，支持进度/取消/原子化写入",
            "✨【新增】_on_export_progress回调：实时显示进度百分比和ETA",
            "✨【新增】_on_export_done回调：弹窗询问是否打开文件夹",
            "✨【新增】_on_export_error回调：清理临时文件，显示错误信息",
            "✨【新增】_clean_temp_exports()方法：启动时清理temp/目录下超过1小时的.tmp.xlsx",
            "✨【新增】self.is_exporting状态锁：防止重复导出",
            "🔧【改进】导出流程不阻塞UI，支持取消操作",
            "🔧【改进】文件名去重：自动添加_1, _2后缀避免覆盖"
        ]
    },
    {
        "version": "v36.36.0",
        "date": "2026-05-17 11:34:00",
        "changes": [
            "✨【新增】AI审核异步化：_run_ai_audit改为启动器+进度条determinate模式",
            "✨【新增】AIClient类（core/ai_client.py）：Mock模式+熔断机制（10秒超时）",
            "✨【新增】_ai_audit_worker：cancel_flag.is_set()检查，动态查找文本列，找不到跳过",
            "✨【新增】_on_ai_audit_done/_on_ai_audit_error：异常分类处理，结果窗口+状态标签",
            "✨【新增】TaskManager._thread_safe_append+on_progress回调+poll轮询机制",
            "✨【新增】app.py注册task_manager.poll(self.root)轮询，自动触发root.update()",
            "✨【新增】self.is_auditing/self.unsaved_ai_results/self._pending_audit_count状态",
            "✨【新增】取消审核按钮（ui_builder.py cancel_audit_btn），橙底白字disabled默认",
            "🔧【改进】_run_ai_audit：worker用lambda传递cancel_flag和progress_callback参数",
            "🔧【改进】lambda参数传递验证：kwargs键名c/p与lambda参数名一致，对应正确"
        ]
    },
    {
        "version": "v36.35.0",
        "date": "2026-05-17 10:24:00",
        "changes": [
            "✨【新增】快捷键系统：Ctrl+S保存、Ctrl+E导出、Ctrl+A AI审核、F1帮助、Ctrl+Q退出",
            "✨【新增】菜单栏帮助菜单：快捷键说明对话框（_show_shortcuts_help）"
        ]
    },
    {
        "version": "v36.34.0",
        "date": "2026-05-17 07:22:00",
        "changes": [
            "✨【新增】F4 自动结案：按审核状态筛选，仅对已审核行执行自动结案",
            "✨【新增】F11 反馈装饰器（core/decorators.py with_feedback），装饰7个关键函数，操作后弹成功提示",
            "✨【新增】F12 进度条雏形（core/task_manager.py TaskManager + Progressbar）",
            "✨【新增】隔离区按钮绑定 _move_to_quarantine",
            "🔧【修复】F1 多列排序冲突：注释 app.py 中 bind_multi_sort 调用，保留 EventsMixIn 单一排序系统",
            "🔧【修复】按钮布局拥挤：ui_builder.py 底部按钮单行拆为双行（row1 + row2）",
            "🔧【修复】打包版本日志自动同步"
        ]
    },
    {
        "version": "v36.33.0",
        "date": "2026-05-17 06:27:11",
        "changes": [
            "🔧【修复】打包版本日志自动同步"
        ]
    },
    {
        "version": "v36.32.0",
        "date": "2026-05-17 00:30:00",
        "changes": [
            "🔧【修复】PO-1 趋势分析负数显示（数值取绝对值，箭头方向不变）",
            "🏗️【重构】版本号管理集中化：创建 utils/version_history.py，消除所有硬编码"
        ]
    },
    {
        "version": "v36.31.0",
        "date": "2026-05-16 18:49:21",
        "changes": [
            "🔧【修复】打包版本日志自动同步"
        ]
    },
    {
        "version": "v36.30.0",
        "date": "2026-05-16 18:22:45",
        "changes": [
            "🔧【修复】打包版本日志自动同步"
        ]
    },
    {
        "version": "v36.29.0",
        "date": "2026-05-16 18:00:00",
        "changes": [
            "🔧【修复】版本日志显示逻辑：兼容changes数组格式，自动识别前缀符号并正确渲染"
        ]
    },
    {
        "version": "v36.28.0",
        "date": "2026-05-16 17:55:00",
        "changes": [
            "🔧【修复】修复打开Excel失败：load_workbook未导入gui/events.py",
            "🔧【修复】修正替代料配置文件路径，加载完整20对数据",
            "🔧【修复】迁移替代料配置到标准用户目录（AppData\\Roaming\\ZPP011\\config）",
            "📌【教训】打包脚本含--clean参数，dist目录必须先备份再打包"
        ]
    },
    {
        "version": "v36.27.0",
        "date": "2026-05-16 18:00:00",
        "changes": [
            "🔧【修复】修正替代料配置文件路径，加载完整20对数据",
            "🔧【修复】迁移替代料配置到标准用户目录（AppData\\Roaming\\ZPP011\\config）"
        ]
    },
    {
        "version": "v36.26.0",
        "date": "2026-05-16 17:20:00",
        "changes": [
            "🔧【修复】修复打开Excel失败：load_workbook未导入gui/events.py"
        ]
    },
    {
        "version": "v36.25.0",
        "date": "2026-05-16 15:50:00",
        "changes": [
            "🔧【修复】批量备注：恢复被误删的 _get_remark_freq_path 方法定义，修复 AttributeError 崩溃"
        ]
    },
    {
        "version": "v36.24.0",
        "date": "2026-05-16 15:20:00",
        "changes": [
            "🔧【修复】替代料添加：_load_material_list() 现已接入 _preview()，每次加载Excel后自动刷新物料列表下拉框",
            "🔧【修复】app.py：初始化 material_list 和 code_to_info 实例变量，防止未定义报错"
        ]
    },
    {
        "version": "v36.23.0",
        "date": "2026-05-16 14:52:00",
        "changes": [
            "🔧【修复】批量备注：恢复Combobox下拉框选择，支持预设备注+自定义输入+追加换行"
        ]
    },
    {
        "version": "v36.22.0",
        "date": "2026-05-16 14:28:52",
        "changes": [
            "✨【新增】_batch_remark：批量备注基础版，simpledialog输入框、excel_row定位、追加换行（分隔/）",
            "✨【新增】批量备注按钮绑定新函数 _batch_remark（替换 _batch_fill_remark）",
            "🔧【修复】批量备注：树形列改为 batch_remark，DataFrame优先写批量备注列，fallback到备注原因",
            "🔧【修复】导出Excel：_generate_excel_thread 使用 self.input_file.get()，generate_excel_direct传参修正",
            "🔧【修复】排序系统：禁用 tree_utils.setup_column_sorting 冲突绑定，删除重复死代码"
        ]
    },
    {
        "version": "v36.20.0",
        "date": "2026-05-16 13:38:53",
        "changes": [
            "🔧【修复】ui_builder.py：audit_tree heading顺序重排，与cols定义完全对齐",
            "🔧【修复】sheet5_full.py：偏差金额增加双重容错逻辑（单价缺失时反算）",
            "🔧【修复】events.py：审核来源（audit_source）三处均添加默认值推断（AI/手动/系统）",
            "🔧【验证】values元组顺序与cols一致，无列数据错位风险"
        ]
    },
    {
        "version": "v36.18.0",
        "date": "2026-05-16",
        "changes": [
            "✨【功能】多列联动排序（无上限追加）",
            "⚡【优化】移除order_no重复标题定义",
            "🔧【修复】排序方法移入EventsMixIn类内部"
        ]
    },
    {
        "version": "v36.17.0",
        "date": "2026-05-16",
        "changes": [
            "✨【功能】多列联动排序：点击列头排序，点击同列升降序切换，多列追加排序（无上限）",
            "⚡【优化】移除ui_builder.py中order_no列标题重复定义",
            "🔧【修复】排序方法移入EventsMixIn类内部（修复AttributeError）"
        ]
    },
    {
        "version": "v36.16",
        "date": "2026-05-16",
        "features": [
            "多列联动排序：无上限，点击列头切换升/降序，支持多级排序"
        ],
        "fixes": [],
        "optimizations": [],
        "lessons": []
    },
    {
        "version": "v36.15",
        "date": "2026-05-16",
        "features": [],
        "fixes": [
            "标题栏版本号从写死v36改为动态读取version.json",
            "审核状态改为基于audit_result列判断",
            "审核来源改为从审核来源列读取",
            "偏差金额从audit_df映射解决为0问题",
            "调整列顺序：生产管理员→订单日期→流程订单→物料号"
        ],
        "optimizations": [],
        "lessons": []
    },
    {
        "version": "v36.14",
        "date": "2026-05-16",
        "features": [],
        "fixes": [
            "分析完成后自动删除生成的Excel文件，用户需手动点击生成Excel按钮"
        ],
        "optimizations": [],
        "lessons": []
    },
    {
        "version": "v36.13",
        "date": "2026-05-16",
        "features": [],
        "fixes": [
            "修复预检报告重复订单检测不兼容组件物料号列名",
            "修复_fill_table方法不存在导致表格更新崩溃",
            "修复表格列顺序错位（缺少audit_status和audit_source）",
            "修复_get_quarantine_path中变量d未定义",
            "修复树形视图列名硬编码不兼容当前数据列名",
            "新增流程订单列到表格显示"
        ],
        "optimizations": [],
        "lessons": []
    },
    {
        "version": "v36.12",
        "date": "2026-05-16",
        "features": [],
        "fixes": [
            "修复加载审核数据时订单列查找失败的问题（增加更多候选列名，处理列名不存在的情况）",
            "修复AI审核按钮无法使用（重写 _run_ai_audit 方法，修正未定义变量和循环逻辑）",
            "修复隔离区相关功能（统一隔离区辅助方法，避免重复定义）",
            "修复列宽锁定无效（绑定正确的事件处理函数）",
            "修复自动结案按钮无效（增加异常捕获和日志）",
            "修复隔离区弹窗列名显示英文（改为中文表头）",
            "修复预检报告弹窗（完整实现 _run_pre_check 生成 results 并调用弹窗）",
            "修复偏差金额合计为0（读取分析结果中的偏差金额列，若无则从单价计算）",
            "修复成本换算器（在审核卡片中正确显示）"
        ],
        "optimizations": [],
        "lessons": []
    },
    {
        "version": "v36.11",
        "date": "2026-05-14",
        "features": [
            '替代料配对区域新增"📄 查看配置"按钮，可查看 alt_pairs.json 内容（只读，可复制）',
            '底部按钮栏新增"📝 批量操作"按钮（随机码确认 + 批量处理）',
        ],
        "fixes": [
            'AI审核弹窗改为内嵌实现（不再依赖外部 show_result_window），修复弹窗不显示问题',
            '列宽锁定逻辑重写：改用 <<TreeviewColumnResized>> 事件绑定替代定时器轮询',
            '列宽锁定不再重置所有列宽（只阻止拖动），解锁后调整实时保存',
            '所有列统一设置 stretch=False，解决调整列宽时挤压其他列的问题',
            '修复 widgets.py 未被 PyInstaller 打包导致 exe 崩溃（添加 --paths + --hidden-import）',
            '审核来源不再被备注来源覆盖（优先读取 Excel 原始审核来源列）',
            'AI审核仅对当前审核行设置审核来源，不影响其他行',
        ],
        "optimizations": [
            'build.py 添加 --paths 和 --hidden-import widgets，确保项目根目录模块被正确打包',
            '列宽事件驱动替代定时器轮询，减少 CPU 占用',
            'build_log 详细格式：按前缀自动归类（新增/改进/修复/优化），含打包人/Python版本/文件大小/耗时',
        ],
        "lessons": [
            'Tkinter Treeview stretch=False 必须在所有 column() 调用中设置，否则调整一列会挤压其他列',
            'PyInstaller 以子目录脚本为入口时，需 --paths 显式指定项目根目录',
        ]
    },
    {
        "version": "v36.6",
        "date": "2026-05-13",
        "features": [],
        "fixes": [
            '审核来源不再被备注来源覆盖（优先读取 Excel 原始审核来源列）',
            'AI审核仅对当前审核行设置审核来源，不影响其他行',
        ],
        "optimizations": [],
        "lessons": []
    },
    {
        "version": "v36.5",
        "date": "2026-05-13",
        "features": [],
        "fixes": [
            '状态列与审核状态列彻底分离：状态=已备注/未备注（基于备注原因），审核状态=已审核/未审核（基于audit_result）',
            '状态筛选下拉选项改为"已备注"/"未备注"，正确过滤',
            'AI审核弹窗改为调用独立 show_result_window 函数，支持复制到剪贴板',
            '加载数据时自动设置状态列和审核状态列',
            'show_result_window 独立函数添加，显示5列（物料、偏差率、原备注、AI建议、审核结果）',
        ],
        "optimizations": [],
        "lessons": []
    },
    {
        "version": "v36.4",
        "date": "2026-05-13",
        "features": [],
        "fixes": [
            "AI审核重写：进度条、智能建议（广宣/包装/备件分类）、不覆盖原始备注、弹窗5列",
            "偏差金额正确计算并显示（原为0）：自动从金额-实际(含税)/数量-实际推算单价",
            '审核表格新增"审核状态"列（已审核/未审核）和"审核来源"列',
            '修正状态术语：审核状态基于 audit_result 判断',
            "删除 app.py 中两段孤立死代码",
            "偏差金额列移至偏差率之后，表格列顺序优化",
        ],
        "optimizations": [],
        "lessons": []
    },
    {
        "version": "v36.3",
        "date": "2026-05-13",
        "features": [],
        "fixes": [
            "修复 pandas 3.0.2 环境下 Lengths of operands do not match: 4 != 3 错误",
            "sheet8_reason_summary.py: agg lambda 返回值强制 str()/float() 包裹，防止非标量返回",
            "analyzer.py: .loc 列赋值右侧加 .values，避免索引不对齐",
            "sheet2_alt.py: alt_pairs 安全解包 + 类型校验，防止 tuple 泄漏到字符串比较",
            "sheet4_middle.py: alt_pairs 列表推导改用安全列表构建",
            "新增3对替代料配对（乐虎500ml、复配XD2139-5A、南侨玛琪琳），总数 17→20 对",
            "版本日志硬编码，消除 EXE 打包路径依赖",
            "审核按钮启用逻辑独立于数据加载，确保分析完成后始终可用",
            "审核按钮回调添加 try-except 错误弹窗，避免静默失败",
        ],
        "optimizations": [],
        "lessons": []
    },
]


# ── 公共函数 ──────────────────────────────────────────

def get_current_version():
    """返回当前版本号字符串，如 'v36.32.0'"""
    if VERSION_HISTORY:
        return VERSION_HISTORY[0]["version"]
    return "v0.0.0"


def get_version_display():
    """返回窗口标题用的完整显示名，如 '云南达利ZPP011生产偏差分析器_v36.32.0'"""
    return f"{APP_NAME}_{get_current_version()}"


def get_version_history_text():
    """
    返回格式化的版本日志文本，供"关于"窗口使用。
    每次调用都从 VERSION_HISTORY 实时生成，不缓存。
    """
    lines = [
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
        "📋 版本日志",
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    ]

    for v in VERSION_HISTORY:
        lines.append(f"【{v['version']}】{v.get('date', '')}")

        # 新格式：features / fixes / optimizations / lessons
        for feat in v.get('features', []):
            lines.append(f"  ✦ {feat}")
        for fix in v.get('fixes', []):
            lines.append(f"  🔧 {fix}")
        for opt in v.get('optimizations', []):
            lines.append(f"  ⚡ {opt}")
        for les in v.get('lessons', []):
            lines.append(f"  📌 {les}")
        for note in v.get('notes', []):
            lines.append(f"  📌 {note}")

        # 旧格式兼容：changes 数组（根据前缀符号判断类型）
        for change in v.get('changes', []):
            if '【新增】' in change or '✨' in change or '✦' in change:
                content = change.replace('✨', '').replace('✦', '').replace('【新增】', '').strip()
                lines.append(f"  ✦ {content}")
            elif '【修复】' in change or '🔧' in change:
                content = change.replace('🔧', '').replace('【修复】', '').strip()
                lines.append(f"  🔧 {content}")
            elif '【优化】' in change or '⚡' in change:
                content = change.replace('⚡', '').replace('【优化】', '').strip()
                lines.append(f"  ⚡ {content}")
            elif '📌' in change or '【教训】' in change:
                content = change.replace('📌', '').replace('【教训】', '').strip()
                lines.append(f"  📌 {content}")
            else:
                lines.append(f"  🔧 {change}")

        lines.append("")

    return "\n".join(lines).strip()
